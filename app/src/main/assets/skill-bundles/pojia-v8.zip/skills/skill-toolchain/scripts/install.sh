#!/bin/sh
# 安装技能依赖工具；已存在的跳过。Debian 走 apt + pip，Alpine 走 apk + pip。
# 需要联网；首次执行通常要几分钟。可选工具装不上不影响其它项。
set -u
have() { command -v "$1" >/dev/null 2>&1; }
have_pip() { python3 -m pip --version >/dev/null 2>&1; }
is_debian=0; [ -f /etc/debian_version ] && is_debian=1

apt_install() { [ $# -eq 0 ] && return 0; echo "[apt] $*"; apt-get install -y --no-install-recommends "$@" || echo "!! apt 失败：$*"; }
apk_install() { [ $# -eq 0 ] && return 0; echo "[apk] $*"; apk add --no-cache "$@" || echo "!! apk 失败：$*"; }
pip_install() { [ $# -eq 0 ] && return 0; echo "[pip] $*"; python3 -m pip install --break-system-packages --no-cache-dir "$@" || echo "!! pip 失败：$*"; }
apt_has() { apt-cache policy "$1" 2>/dev/null | grep -q 'Candidate: [^(]'; }

# pip 的入口脚本装在 python 自己的 bin 目录（/opt/eta/python/.../bin），不在 PATH 里。
# 装完把这些入口软链到 /usr/local/bin，技能里的 `frida`、`mitmdump` 才找得到。
link_entrypoints() {
  sdir=$(python3 -c "import sysconfig;print(sysconfig.get_path('scripts'))" 2>/dev/null) || sdir=""
  [ -n "$sdir" ] && [ -d "$sdir" ] || return 0
  n=0
  for src in "$sdir"/frida "$sdir"/frida-* "$sdir"/mitmproxy "$sdir"/mitmdump "$sdir"/mitmweb \
             "$sdir"/pwn "$sdir"/checksec "$sdir"/ROPgadget "$sdir"/ropper "$sdir"/one_gadget; do
    [ -f "$src" ] || continue
    b=$(basename "$src")
    [ -e "/usr/local/bin/$b" ] && continue
    if ln -s "$src" "/usr/local/bin/$b" 2>/dev/null; then n=$((n+1)); fi
  done
  echo "[link] /usr/local/bin 新增 $n 个入口（pip scripts=$sdir）"
}

if [ $is_debian -eq 1 ]; then
  apt-get update -o Acquire::Retries=2 || true
  pkg=""
  have python3 || pkg="$pkg python3"
  have node || pkg="$pkg nodejs npm"
  have git || pkg="$pkg git"
  have curl || pkg="$pkg curl"
  have unzip || pkg="$pkg unzip"
  have java || pkg="$pkg openjdk-17-jre-headless"
  apt_install $pkg
else
  apk update || true
  pkg=""
  have python3 || pkg="$pkg python3"
  have node || pkg="$pkg nodejs npm"
  have git || pkg="$pkg git"
  have curl || pkg="$pkg curl"
  have unzip || pkg="$pkg unzip"
  have java || pkg="$pkg openjdk17-jre-headless"
  apk_install $pkg
fi

# python3 自带 pip，不必装 python3-pip（那会落到系统 python 上，对 Eta 自带解释器无效）。
have_pip || { echo "[pip] ensurepip"; python3 -m ensurepip --upgrade >/dev/null 2>&1 || echo "!! ensurepip 失败"; }

have mitmproxy || pip_install mitmproxy
have frida || pip_install frida-tools
link_entrypoints

if ! have pwn; then
  pip_install pwntools
  if ! have pwn && ! python3 -c "import pwn" 2>/dev/null; then
    echo "[skip] pwntools 需要编译 unicorn（要 gcc + cmake）："
    echo "       apt-get install -y build-essential cmake && 再跑一次本脚本"
    echo "       只用 ROP/汇编时 pip install ropgadget 更轻"
  fi
fi

if ! have r2; then
  if [ $is_debian -eq 1 ] && apt_has radare2; then
    apt_install radare2
  elif [ $is_debian -eq 0 ]; then
    apk_install radare2
  else
    echo "[skip] radare2 不在本发行版仓库，需自行编译："
    echo "       git clone --depth 1 https://github.com/radareorg/radare2 && radare2/sys/install.sh"
  fi
fi

link_entrypoints
echo
echo "== 复查"
sh "$(dirname "$0")/check.sh"
