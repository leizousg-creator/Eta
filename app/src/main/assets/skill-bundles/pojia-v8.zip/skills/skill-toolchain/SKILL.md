---
name: skill-toolchain
description: 技能依赖体检与安装。当技能里的命令报 command not found、frida/radare2/mitmproxy/pwntools 等工具缺失，或刚装了一批技能不确定环境够不够时使用。
---

# 技能依赖体检

技能文档写得再全，缺工具也跑不起来。这个技能负责「先查缺什么、再补上」。

## 什么时候用

- 技能里的命令报 `command not found` / `No such file or directory`
- 刚导入一批技能，想知道当前 Linux 环境缺什么
- 需要 frida、radare2、mitmproxy、pwntools 这类不常备的工具

## 第一步：查

```sh
sh /root/skills/skill-toolchain/scripts/check.sh
```

输出分两组：

| 组 | 工具 | 缺了会怎样 |
|---|---|---|
| 必需 | python3、pip、node、npm、git、curl、unzip、java、jadx、apktool | 退出码 1，很多技能直接跑不动 |
| 可选（按需） | frida、r2、mitmproxy、pwn | 只提示，不影响退出码 |

退出码 0 = 必需项齐全。可选工具缺了只在真要用时再装。

## 第二步：装

```sh
sh /root/skills/skill-toolchain/scripts/install.sh
```

- Debian 走 `apt-get`，Alpine 走 `apk`；pip 一律 `python3 -m pip --break-system-packages`
- 只装缺的，已存在的跳过；单项失败只打 `!!`，不中断后续
- 装完自动再跑一次 check.sh 复查
- 首次执行要联网，通常几分钟

## 注意

- **jadx / apktool 不在发行版仓库里**，Eta 自带 `/usr/local/bin/jadx`、`/usr/local/bin/apktool`；check 显示 OK 就不要重复装。
- **pip 要认 `python3 -m pip`**：Eta 的 python3 在 `/opt/eta/python/...`，`pip3` 命令常常不存在但 pip 模块可用，装 `python3-pip` 只会落到系统 python 上，白装。
- **radare2 多数 Debian 仓库没有包**：脚本检测到无候选会跳过并打印编译命令（`git clone --depth 1 https://github.com/radareorg/radare2 && radare2/sys/install.sh`）。命令名是 `r2`/`rabin2`。
- `frida` 命令存在 ≠ 能 hook：attach 其他进程需要 root，目标进程可能还有反调试。
- **pip 装完要链入口**：pip 把 `frida`、`mitmproxy` 这些可执行文件装进 python 自己的 bin 目录（`/opt/eta/python/.../bin`），那个目录不在 PATH 里。install.sh 会自动软链到 `/usr/local/bin`，手动装的话要自己补：
  `ln -s "$(python3 -c 'import sysconfig;print(sysconfig.get_path("scripts"))')/frida" /usr/local/bin/frida`
- `pwntools`（命令 `pwn`）要编译 unicorn 的 C 扩展，缺 gcc + cmake 会失败；只做 ROP/汇编时 `pip install ropgadget` 更轻。
- 装完**新开一个终端会话**，旧会话的 PATH 可能没刷新。

## 常见缺口对照

| 工具 | 安装方式 |
|---|---|
| frida / frida-tools | `python3 -m pip install frida-tools` |
| mitmproxy | `python3 -m pip install mitmproxy` |
| pwntools（命令 `pwn`） | `python3 -m pip install pwntools` |
| radare2（命令 `r2`） | 仓库有就 `apt-get install radare2`，没有就源码编译 |
| node / npm | `apt-get install nodejs npm` |
| java | `apt-get install openjdk-17-jre-headless` |
| jadx / apktool | 已随 Eta 提供，无需安装 |
