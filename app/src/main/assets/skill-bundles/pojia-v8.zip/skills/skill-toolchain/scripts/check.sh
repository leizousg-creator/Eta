#!/bin/sh
# 技能依赖体检：检查已装技能引用到的工具是否在 Linux 环境里可用。
# Debian / Alpine 通用。
# 退出码：0 = 必需项齐全（可选工具缺失只提示），1 = 必需项有缺失。
set -u
have() { command -v "$1" >/dev/null 2>&1; }
have_pip() { python3 -m pip --version >/dev/null 2>&1; }
req=""; opt=""
check() { # $1=tool  $2=required|optional
  if have "$1"; then printf '%-14s OK      %s\n' "$1" "$(command -v "$1")"; return; fi
  printf '%-14s MISSING\n' "$1"
  if [ "$2" = "required" ]; then req="$req $1"; else opt="$opt $1"; fi
}
echo "== 必需"
check python3 required
if have_pip; then printf '%-14s OK      %s\n' "pip" "$(python3 -m pip --version 2>/dev/null | cut -d' ' -f2) (python3 -m pip)"
else printf '%-14s MISSING\n' "pip"; req="$req pip"; fi
for t in node npm git curl unzip java; do check "$t" required; done
echo "== 逆向 / 安全（按需）"
for t in jadx apktool; do check "$t" required; done
for t in frida r2 mitmproxy pwn; do check "$t" optional; done
echo
if [ -n "$req" ]; then
  echo "必需缺失:$req"
  echo "在技能目录运行 scripts/install.sh 安装（Debian 用 apt/pip，Alpine 用 apk/pip）"
  exit 1
fi
if [ -n "$opt" ]; then
  echo "必需项就绪；可选缺失:$opt（用到再装，见 SKILL.md）"
else
  echo "全部就绪"
fi
exit 0
